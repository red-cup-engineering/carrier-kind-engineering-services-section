# Infomaterial Layout Service

This settlement is the read-only EDA layout die for measured informational
material. It consumes content-addressed topology and conductor artifacts,
verifies their canonical bytes, overlays asserted authority boundaries, and
emits circuit-layout DRC evidence. It never treats a directory, package,
office, section, or existing wallet as an earned die merely because it exists.

Its internal circuits verify material topology, verify conductor evidence,
resolve observed occurrences, assay cross-boundary conduction, measure
internal cohesion, and state the missing authority, custody, refusal,
amendment, value, protocol, and deployment evidence needed to earn a cut.

It does not read unmeasured customer source, mutate customer territory,
provision accounts, certify its own implementation, or turn unresolved
evidence into a proposed enterprise. Layout synthesis and material etching are
different authority surfaces. JSON output is diagnostic projection only; RMN
identity and RWIL/RDF receipts remain authoritative.
