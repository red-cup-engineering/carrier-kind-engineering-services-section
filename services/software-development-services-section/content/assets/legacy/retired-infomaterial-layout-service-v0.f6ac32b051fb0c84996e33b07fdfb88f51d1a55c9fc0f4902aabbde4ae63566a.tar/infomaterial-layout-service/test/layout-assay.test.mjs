import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { assayInfomaterialLayout } from "../src/layout-assay.mjs";

const P = "urn:emsenn:infomaterial:";
function ni(label) { return `ni:///sha-256;${createHash("sha256").update(label).digest("base64url")}`; }
function nq(subject, predicate, object, graph) { return `<${subject}> <${P}${predicate}> ${object} <${graph}> .`; }
function iri(value) { return `<${value}>`; }
function lit(value) { return JSON.stringify(value); }
async function artifact(directory, name, lines) {
  const bytes = `${[...lines].sort((a, b) => Buffer.compare(Buffer.from(a), Buffer.from(b))).join("\n")}\n`;
  const path = join(directory, name); await writeFile(path, bytes);
  return { path, identity: `ni:///sha-256;${createHash("sha256").update(bytes).digest("base64url")}` };
}

test("operation nuclei are measured independently of incumbent account and package claims", async () => {
  const directory = await mkdtemp(join(tmpdir(), "infomaterial-layout-")), topologyGraph = ni("topology-graph"), conductorGraph = ni("conductor-graph");
  const occurrence = Object.fromEntries([".", "a", "a/package.json", "a/src", "a/src/main.mjs", "a/src/shared.mjs", "a/account.json", "b", "b/package.json", "b/src", "b/src/helper.mjs", "b/account.json"].map((path) => [path, ni(`occurrence:${path}`)]));
  const material = Object.fromEntries(Object.keys(occurrence).map((path) => [path, ni(`material:${path}`)]));
  const topologyLines = [];
  for (const path of Object.keys(occurrence)) {
    topologyLines.push(nq(occurrence[path], "material", iri(material[path]), topologyGraph));
    topologyLines.push(nq(occurrence[path], "path", lit(path), topologyGraph));
    if (path !== ".") { const parent = path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "."; topologyLines.push(nq(occurrence[path], "parent-occurrence", iri(occurrence[parent]), topologyGraph)); }
  }
  const topologyArtifact = await artifact(directory, "topology.nq", topologyLines);
  const conductorLines = [];
  function record(label, type, source, fields) {
    const subject = ni(`evidence:${label}`);
    conductorLines.push(nq(subject, "conductor-type", iri(`${P}${type}`), conductorGraph));
    conductorLines.push(nq(subject, "source-occurrence", iri(occurrence[source]), conductorGraph));
    conductorLines.push(nq(subject, "source-material", iri(material[source]), conductorGraph));
    for (const [field, value] of Object.entries(fields)) conductorLines.push(nq(subject, field, value.startsWith?.("ni:///") ? iri(value) : lit(value), conductorGraph));
  }
  record("claim-a", "AccountBoundaryClaimEvidence", "a/account.json", { "target-occurrence": occurrence.a, "analysis-status": "parsed", "account-claim": "eip155:31337:0x1111111111111111111111111111111111111111", "actor-claim": "urn:test:a", "node-id-claim": "a" });
  record("claim-b", "AccountBoundaryClaimEvidence", "b/account.json", { "target-occurrence": occurrence.b, "analysis-status": "parsed", "account-claim": "eip155:31337:0x2222222222222222222222222222222222222222", "actor-claim": "urn:test:b", "node-id-claim": "b" });
  record("bin-a", "PackageBinConductorEvidence", "a/package.json", { "target-occurrence": occurrence["a/src/main.mjs"], resolution: "package-bin-target", "bin-name": "operate-a", specifier: "./src/main.mjs" });
  record("main-shared", "ModuleConductorEvidence", "a/src/main.mjs", { "target-occurrence": occurrence["a/src/shared.mjs"], resolution: "relative-module", specifier: "./shared.mjs", "import-kind": "static-import" });
  record("shared-helper", "ModuleConductorEvidence", "a/src/shared.mjs", { "target-occurrence": occurrence["b/src/helper.mjs"], resolution: "relative-module", specifier: "../../b/src/helper.mjs", "import-kind": "static-import" });
  record("supply-b", "PackageSupplyConductorEvidence", "a/package.json", { "target-occurrence": occurrence["b/package.json"], resolution: "workspace-package-claim", "package-name": "@test/b", "dependency-field": "dependencies", requirement: "file:../b" });
  const conductorArtifact = await artifact(directory, "conductors.nq", conductorLines);
  const result = await assayInfomaterialLayout({
    topology: { ...topologyArtifact, graph: topologyGraph, materialRoot: material["."], entries: Object.keys(occurrence).length },
    conductors: { ...conductorArtifact, graph: conductorGraph },
  });
  assert.equal(result.earnedCuts, 0);
  assert.equal(result.claimedRegions.length, 2);
  assert.equal(result.directCrossClaimModules.length, 1);
  assert.equal(result.crossClaimSupplies.length, 1);
  assert.equal(result.ambientFileSupplies.length, 1);
  assert.deepEqual(result.operationNuclei.map(({ operation, dependencyClosureOccurrences, assertedAccountCoverage }) => ({ operation, dependencyClosureOccurrences, assertedAccountCoverage })), [{
    operation: "operate-a", dependencyClosureOccurrences: 3,
    assertedAccountCoverage: ["eip155:31337:0x1111111111111111111111111111111111111111", "eip155:31337:0x2222222222222222222222222222222222222222"],
  }]);
  assert.ok(result.operationNuclei[0].blockers.includes("authority:2-account-claims-crossed"));
});
