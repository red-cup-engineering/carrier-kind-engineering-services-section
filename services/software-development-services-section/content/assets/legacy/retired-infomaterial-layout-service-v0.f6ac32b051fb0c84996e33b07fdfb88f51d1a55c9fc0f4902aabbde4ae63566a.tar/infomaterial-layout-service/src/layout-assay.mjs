import { createReadStream } from "node:fs";
import { createInterface } from "node:readline";
import { verifyConductorProjection, one } from "./conductor-gate.mjs";
import { verifyMaterialTopology } from "./topology-gate.mjs";

const PATH_QUAD = /^<(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})> <urn:emsenn:infomaterial:path> ("(?:[^"\\]|\\.)*") <ni:\/\/\/sha-256;[A-Za-z0-9_-]{43}> \.$/u;
function utf8Compare(left, right) { return Buffer.compare(Buffer.from(left, "utf8"), Buffer.from(right, "utf8")); }
function unique(values) { return [...new Set(values)].sort(utf8Compare); }
function within(root, path) { return root === "." || path === root || path.startsWith(`${root}/`); }

async function occurrencePaths(topologyPath, wanted) {
  const found = new Map(), lines = createInterface({ input: createReadStream(topologyPath), crlfDelay: Infinity });
  for await (const line of lines) { const match = line.match(PATH_QUAD); if (match && wanted.has(match[1])) found.set(match[1], JSON.parse(match[2])); }
  const missing = [...wanted].filter((identity) => !found.has(identity)); if (missing.length) throw new Error(`topology omits conductor occurrence ${missing.sort(utf8Compare)[0]}`); return found;
}
function claimFor(path, claims) { return claims.filter(({ rootPath }) => within(rootPath, path)).sort((a, b) => b.rootPath.length - a.rootPath.length)[0] ?? null; }
function connectedComponents(nodes, edges) {
  const adjacent = new Map([...nodes].map((node) => [node, new Set()]));
  for (const [left, right] of edges) { if (!adjacent.has(left) || !adjacent.has(right)) continue; adjacent.get(left).add(right); adjacent.get(right).add(left); }
  const seen = new Set(); let count = 0;
  for (const start of adjacent.keys()) if (!seen.has(start)) { count += 1; const pending = [start]; seen.add(start); while (pending.length) for (const next of adjacent.get(pending.pop())) if (!seen.has(next)) { seen.add(next); pending.push(next); } }
  return count;
}
function reachableFrom(start, outgoing) {
  const reached = new Set([start]), pending = [start];
  while (pending.length) {
    const source = pending.pop();
    for (const target of outgoing.get(source) ?? []) if (!reached.has(target)) { reached.add(target); pending.push(target); }
  }
  return reached;
}

export async function assayInfomaterialLayout({ topology, conductors }) {
  const topologyResult = await verifyMaterialTopology(topology), conductorResult = await verifyConductorProjection(conductors);
  const wanted = new Set();
  for (const record of conductorResult.records) for (const field of ["source-occurrence", "target-occurrence"]) { const identity = one(record, field); if (identity) wanted.add(identity); }
  const paths = await occurrencePaths(topology.path, wanted);
  const claimEvidence = conductorResult.records.filter(({ type }) => type === "AccountBoundaryClaimEvidence").map((record) => {
    const rootOccurrence = one(record, "target-occurrence"), sourceOccurrence = one(record, "source-occurrence", { required: true });
    return { evidence: record.subject, sourceOccurrence, rootOccurrence, rootPath: rootOccurrence ? paths.get(rootOccurrence) : null, account: one(record, "account-claim"), actor: one(record, "actor-claim"), nodeId: one(record, "node-id-claim"), status: one(record, "analysis-status") };
  });
  const claims = claimEvidence.filter(({ rootPath }) => rootPath !== null).sort((a, b) => utf8Compare(`${a.rootPath}\u0000${a.account}`, `${b.rootPath}\u0000${b.account}`));
  const unresolvedClaims = claimEvidence.filter(({ rootPath }) => rootPath === null).sort((a, b) => utf8Compare(a.evidence, b.evidence));
  const conductorRecords = conductorResult.records.filter(({ type }) => ["ModuleConductorEvidence", "PackageSupplyConductorEvidence", "PackageBinConductorEvidence"].includes(type));
  const resolved = [], unresolved = [], directCrossClaimModules = [], crossClaimSupplies = [], ambientFileSupply = [];
  for (const record of conductorRecords) {
    const sourceOccurrence = one(record, "source-occurrence", { required: true }), targetOccurrence = one(record, "target-occurrence"), sourcePath = paths.get(sourceOccurrence), targetPath = targetOccurrence ? paths.get(targetOccurrence) : null;
    const edge = { evidence: record.subject, type: record.type, sourceOccurrence, sourcePath, targetOccurrence, targetPath, resolution: one(record, "resolution"), specifier: one(record, "specifier"), binName: one(record, "bin-name"), packageName: one(record, "package-name"), dependencyField: one(record, "dependency-field"), requirement: one(record, "requirement") };
    const sourceClaim = claimFor(sourcePath, claims), targetClaim = targetPath ? claimFor(targetPath, claims) : null; edge.sourceAccount = sourceClaim?.account ?? null; edge.targetAccount = targetClaim?.account ?? null;
    if (targetOccurrence) resolved.push(edge); else unresolved.push(edge);
    if (sourceClaim && targetClaim && sourceClaim.rootOccurrence !== targetClaim.rootOccurrence) {
      if (edge.type === "ModuleConductorEvidence") directCrossClaimModules.push(edge);
      if (edge.type === "PackageSupplyConductorEvidence") crossClaimSupplies.push(edge);
    }
    if (edge.type === "PackageSupplyConductorEvidence" && edge.requirement?.startsWith("file:")) ambientFileSupply.push(edge);
  }
  const regions = [];
  for (const claim of claims) {
    const nodes = new Set(), internalEdges = [], incoming = [], outgoing = [];
    for (const edge of resolved.filter(({ type }) => type === "ModuleConductorEvidence")) {
      const sourceInside = within(claim.rootPath, edge.sourcePath), targetInside = within(claim.rootPath, edge.targetPath);
      if (sourceInside) nodes.add(edge.sourceOccurrence); if (targetInside) nodes.add(edge.targetOccurrence);
      if (sourceInside && targetInside) internalEdges.push([edge.sourceOccurrence, edge.targetOccurrence]); else if (sourceInside) outgoing.push(edge.evidence); else if (targetInside) incoming.push(edge.evidence);
    }
    const componentCount = connectedComponents(nodes, internalEdges), violations = directCrossClaimModules.filter((edge) => within(claim.rootPath, edge.sourcePath) || within(claim.rootPath, edge.targetPath));
    const fileSupplies = ambientFileSupply.filter((edge) => within(claim.rootPath, edge.sourcePath));
    const blockers = [
      ...(claim.status === "parsed" && claim.account ? [] : ["valid-account-claim"]),
      ...(componentCount <= 1 ? [] : [`cohesion:${componentCount}-internal-components`]),
      ...(violations.length === 0 ? [] : [`membrane:${violations.length}-cross-claim-conductors`]),
      ...(fileSupplies.length === 0 ? [] : [`supply:${fileSupplies.length}-ambient-file-dependencies`]),
      "authority:unmeasured", "custody:unmeasured", "refusal:unmeasured", "amendment:unmeasured", "value:unmeasured", "pinout:unmeasured", "protocol:unmeasured", "deployment:unmeasured",
    ];
    regions.push({ rootPath: claim.rootPath, rootOccurrence: claim.rootOccurrence, account: claim.account, actor: claim.actor, nodeId: claim.nodeId, moduleOccurrences: nodes.size, internalComponents: componentCount, incomingConductors: unique(incoming).length, outgoingConductors: unique(outgoing).length, crossClaimViolations: violations.length, ambientFileSupplies: fileSupplies.length, cutStatus: "unresolved", blockers: unique(blockers) });
  }
  regions.sort((a, b) => utf8Compare(a.rootPath, b.rootPath));
  const moduleOutgoing = new Map();
  for (const edge of resolved.filter(({ type }) => type === "ModuleConductorEvidence")) {
    const targets = moduleOutgoing.get(edge.sourceOccurrence) ?? new Set(); targets.add(edge.targetOccurrence); moduleOutgoing.set(edge.sourceOccurrence, targets);
  }
  const operationNuclei = [];
  for (const edge of resolved.filter(({ type }) => type === "PackageBinConductorEvidence")) {
    const closure = reachableFrom(edge.targetOccurrence, moduleOutgoing), closurePaths = [...closure].map((occurrence) => paths.get(occurrence));
    const coveringClaims = unique(closurePaths.map((path) => claimFor(path, claims)?.account).filter(Boolean));
    const unresolvedImports = unresolved.filter(({ type, sourceOccurrence }) => type === "ModuleConductorEvidence" && closure.has(sourceOccurrence));
    operationNuclei.push({
      evidence: edge.evidence,
      operation: edge.binName,
      declaredTarget: edge.specifier,
      packageManifestOccurrence: edge.sourceOccurrence,
      packageManifestPath: edge.sourcePath,
      entryOccurrence: edge.targetOccurrence,
      entryPath: edge.targetPath,
      dependencyClosureOccurrences: closure.size,
      assertedAccountCoverage: coveringClaims,
      unresolvedImports: unresolvedImports.length,
      cutStatus: "unresolved",
      blockers: unique([
        ...(coveringClaims.length <= 1 ? [] : [`authority:${coveringClaims.length}-account-claims-crossed`]),
        ...(unresolvedImports.length === 0 ? [] : [`conductivity:${unresolvedImports.length}-unresolved-imports`]),
        "authority:unmeasured", "custody:unmeasured", "refusal:unmeasured", "amendment:unmeasured",
        "value:unmeasured", "pinout:unmeasured", "protocol:unmeasured", "deployment:unmeasured",
      ]),
    });
  }
  operationNuclei.sort((a, b) => utf8Compare(`${a.entryPath}\u0000${a.operation}`, `${b.entryPath}\u0000${b.operation}`));
  return {
    type: "InfomaterialLayoutAssay",
    profile: "org.emsenn.infomaterial-layout.assay.v1",
    materialRoot: topology.materialRoot,
    observationIdentity: topology.graph,
    topologyIdentity: topology.identity,
    conductorIdentity: conductors.identity,
    topology: { entries: topologyResult.entries, statements: topologyResult.statements, bytes: topologyResult.bytes },
    conductorGraph: { statements: conductorResult.statements, bytes: conductorResult.bytes, records: conductorResult.records.length },
    accountClaims: claimEvidence.length,
    unresolvedAccountClaims: unresolvedClaims,
    claimedRegions: regions,
    operationNuclei,
    resolvedConductors: resolved.length,
    unresolvedConductors: unresolved.length,
    directCrossClaimModules,
    crossClaimSupplies,
    ambientFileSupplies: ambientFileSupply,
    earnedCuts: 0,
    conclusion: "operation nuclei are the smallest currently observable circuit candidates; current accounts and packages remain overlays, and no cut is earned without complete typed boundary evidence",
  };
}
