import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { createInterface } from "node:readline";

const NI = /^ni:\/\/\/sha-256;[A-Za-z0-9_-]{43}$/u;
const QUAD = /^<(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})> <([^>]+)> (.+) <(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})> \.$/u;
const IRI = /^<([^<>\s]+)>$/u;
const PREFIX = "urn:emsenn:infomaterial:";
const TYPES = new Set(["ModuleConductorEvidence", "PackageSupplyConductorEvidence", "PackageBinConductorEvidence", "AccountBoundaryClaimEvidence", "CarrierAnalysisRefusal"]);

function fail(message) { const error = new Error(message); error.code = "material-conductor-drc"; throw error; }
function compare(left, right) { return Buffer.compare(Buffer.from(left, "utf8"), Buffer.from(right, "utf8")); }
function value(source) {
  const iri = source.match(IRI); if (iri) return { kind: "iri", value: iri[1] };
  try { const literal = JSON.parse(source); if (typeof literal === "string") return { kind: "literal", value: literal }; } catch {}
  fail("conductor object is neither an ni URI nor an RDF string literal");
}

export async function verifyConductorProjection({ path, identity, graph }) {
  if (typeof path !== "string" || !NI.test(identity ?? "") || !NI.test(graph ?? "")) fail("exact conductor path, identity, and graph are required");
  const lines = createInterface({ input: createReadStream(path), crlfDelay: Infinity }), hash = createHash("sha256"), records = [];
  let previous = null, statements = 0, bytes = 0, current = null;
  function closeSubject() {
    if (!current) return;
    const types = current.values.get("conductor-type") ?? [];
    if (types.length !== 1 || types[0].kind !== "iri" || !types[0].value.startsWith(PREFIX)) fail(`conductor ${current.subject} has no exact type`);
    current.type = types[0].value.slice(PREFIX.length); if (!TYPES.has(current.type)) fail(`conductor ${current.subject} has unknown type ${current.type}`);
    for (const field of ["source-occurrence", "source-material"]) { const values = current.values.get(field) ?? []; if (values.length !== 1 || values[0].kind !== "iri" || !NI.test(values[0].value)) fail(`conductor ${current.subject} has no exact ${field}`); }
    records.push(current);
  }
  for await (const line of lines) {
    if (!line || line.includes("_:")) fail("conductor graph contains an empty statement or blank node");
    if (previous !== null && compare(previous, line) >= 0) fail("conductor statements are not strictly byte-sorted and unique");
    previous = line; const chunk = `${line}\n`; hash.update(chunk); bytes += Buffer.byteLength(chunk); statements += 1;
    const match = line.match(QUAD); if (!match) fail("conductor graph contains a non-profile N-Quad");
    const [, subject, predicate, object, statementGraph] = match; if (statementGraph !== graph) fail("conductor statement escaped its declared named graph");
    if (!predicate.startsWith(PREFIX)) fail("conductor graph contains a foreign predicate");
    if (current?.subject !== subject) { closeSubject(); current = { subject, type: null, values: new Map() }; }
    const field = predicate.slice(PREFIX.length), values = current.values.get(field) ?? []; values.push(value(object)); current.values.set(field, values);
  }
  closeSubject(); const observedIdentity = `ni:///sha-256;${hash.digest("base64url")}`; if (observedIdentity !== identity) fail("conductor artifact bytes do not match their ni identity");
  return { status: "pass", profile: "org.emsenn.infomaterial-layout.conductor-gate.v1", identity, graph, statements, bytes, records };
}

export function one(record, field, { required = false } = {}) {
  const values = record.values.get(field) ?? [];
  if (values.length > 1 || (required && values.length !== 1)) fail(`conductor ${record.subject} has invalid ${field} cardinality`);
  return values[0]?.value ?? null;
}
