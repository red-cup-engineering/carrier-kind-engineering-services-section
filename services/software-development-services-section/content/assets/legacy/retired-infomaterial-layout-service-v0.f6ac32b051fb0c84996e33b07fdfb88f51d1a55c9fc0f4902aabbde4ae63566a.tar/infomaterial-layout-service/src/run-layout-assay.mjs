#!/usr/bin/env node

import { assayInfomaterialLayout } from "./layout-assay.mjs";

const MAX_REQUEST_BYTES = 64 * 1024;

function exactObject(value, keys, label) {
  if (!value || Object.getPrototypeOf(value) !== Object.prototype) throw new Error(`${label} must be an object`);
  const actual = Object.keys(value).sort().join("\u0000"), expected = [...keys].sort().join("\u0000");
  if (actual !== expected) throw new Error(`${label} must expose exactly ${keys.join(", ")}`);
}

async function readRequest() {
  const chunks = []; let bytes = 0;
  for await (const chunk of process.stdin) {
    bytes += chunk.length; if (bytes > MAX_REQUEST_BYTES) throw new Error(`request exceeds ${MAX_REQUEST_BYTES} bytes`); chunks.push(chunk);
  }
  if (bytes === 0) throw new Error("one layout assay request is required on stdin");
  let request; try { request = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { throw new Error("request is not JSON"); }
  exactObject(request, ["operation", "profile", "topology", "conductors"], "request");
  if (request.profile !== "org.emsenn.infomaterial-layout.request.v1" || request.operation !== "assay-infomaterial-layout") throw new Error("unsupported layout assay request");
  exactObject(request.topology, ["path", "identity", "graph", "materialRoot", "entries"], "topology");
  exactObject(request.conductors, ["path", "identity", "graph"], "conductors");
  return request;
}

try {
  const request = await readRequest();
  const report = await assayInfomaterialLayout(request);
  process.stdout.write(`${JSON.stringify({ profile: "org.emsenn.infomaterial-layout.diagnostic.v1", authoritative: false, report })}\n`);
} catch (error) {
  process.stderr.write(`${error.code ?? "layout-assay-refusal"}: ${error.message}\n`); process.exitCode = 1;
}
