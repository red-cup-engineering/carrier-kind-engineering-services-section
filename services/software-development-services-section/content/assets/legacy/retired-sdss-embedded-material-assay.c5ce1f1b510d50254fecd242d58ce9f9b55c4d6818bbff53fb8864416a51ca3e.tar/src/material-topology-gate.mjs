import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { createInterface } from "node:readline";

const NI = /^ni:\/\/\/sha-256;[A-Za-z0-9_-]{43}$/u;
const PATH = "urn:emsenn:infomaterial:path", PARENT = "urn:emsenn:infomaterial:parent-occurrence", MATERIAL = "urn:emsenn:infomaterial:material";
const QUAD = /^<(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})> <([^>]+)> (.+) <(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})> \.$/u;
const IRI = /^<(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})>$/u;

function fail(message) { const error = new Error(message); error.code = "material-topology-drc"; throw error; }
function compare(left, right) { return Buffer.compare(Buffer.from(left, "utf8"), Buffer.from(right, "utf8")); }
function literal(source) { try { const value = JSON.parse(source); if (typeof value === "string") return value; } catch {} fail("topology path is not a canonical RDF string literal"); }

export async function verifyMaterialTopology({ path, identity, graph, materialRoot, entries }) {
  if (typeof path !== "string" || path.length === 0 || !NI.test(identity ?? "") || !NI.test(graph ?? "") || !NI.test(materialRoot ?? "") || !Number.isSafeInteger(entries) || entries < 1) fail("exact topology path, identities, and entry count are required");
  const input = createReadStream(path), lines = createInterface({ input, crlfDelay: Infinity }), hash = createHash("sha256"), seenPaths = new Set();
  const packageOccurrences = [], accountOccurrences = [], occurrenceSubjects = new Set(), parentReferences = new Set();
  let previous = null, statements = 0, bytes = 0, current = null, rootMaterial = null, occurrenceCount = 0;
  function closeSubject() {
    if (!current?.path) return;
    occurrenceCount += 1;
    if (!current.material) fail(`occurrence ${current.subject} has no material`);
    if (seenPaths.has(current.path)) fail(`topology repeats occurrence path ${current.path}`);
    seenPaths.add(current.path);
    occurrenceSubjects.add(current.subject); if (current.parent) parentReferences.add(current.parent);
    if (current.path === "package.json" || current.path.endsWith("/package.json")) packageOccurrences.push({ path: current.path, material: current.material });
    if (/(?:^|\/)content\/evm\/accounts\/eip155-[0-9]+\.json$/u.test(current.path)) accountOccurrences.push({ path: current.path, material: current.material });
    if (current.path === ".") {
      if (current.parent) fail("root occurrence has a parent");
      if (rootMaterial) fail("topology has more than one root occurrence");
      rootMaterial = current.material;
    } else if (!current.parent) fail(`non-root occurrence ${current.path} has no parent`);
  }
  for await (const line of lines) {
    if (line.length === 0) fail("canonical topology contains an empty statement");
    if (line.includes("_:")) fail("canonical topology contains a blank node");
    if (previous !== null && compare(previous, line) >= 0) fail("topology statements are not strictly byte-sorted and unique");
    previous = line; const chunk = `${line}\n`; hash.update(chunk); bytes += Buffer.byteLength(chunk); statements += 1;
    const match = line.match(QUAD); if (!match) fail("topology contains a non-profile N-Quad");
    const [, subject, predicate, object, statementGraph] = match;
    if (statementGraph !== graph) fail("topology statement escaped its declared named graph");
    if (current?.subject !== subject) { closeSubject(); current = { subject, path: null, parent: null, material: null }; }
    if (predicate === PATH) current.path = literal(object);
    else if (predicate === PARENT) { const value = object.match(IRI); if (!value) fail("parent occurrence is not an ni URI"); current.parent = value[1]; }
    else if (predicate === MATERIAL) { const value = object.match(IRI); if (!value) fail("material reference is not an ni URI"); current.material = value[1]; }
  }
  closeSubject();
  const observedIdentity = `ni:///sha-256;${hash.digest("base64url")}`;
  if (observedIdentity !== identity) fail("topology artifact bytes do not match their ni identity");
  if (rootMaterial !== materialRoot) fail("topology root occurrence does not expose the observed material root");
  if (occurrenceCount !== entries || seenPaths.size !== entries) fail(`topology exposes ${occurrenceCount} unique occurrences, expected ${entries}`);
  for (const parent of parentReferences) if (!occurrenceSubjects.has(parent)) fail(`topology references absent parent occurrence ${parent}`);
  return { status: "pass", profile: "org.emsenn.infomaterial.topology-gate.v1", identity, graph, materialRoot, entries, statements, bytes, packageOccurrences, accountOccurrences };
}
