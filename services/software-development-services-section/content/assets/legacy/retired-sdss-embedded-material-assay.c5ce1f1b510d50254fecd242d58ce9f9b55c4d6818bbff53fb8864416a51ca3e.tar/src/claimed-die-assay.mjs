import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { readFile } from "node:fs/promises";
import { createInterface } from "node:readline";
import { dirname, relative, resolve } from "node:path";
import { verifyMaterialTopology } from "./material-topology-gate.mjs";

const CONTENT = "urn:emsenn:infomaterial:content";
const CONTENT_QUAD = /^<(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})> <urn:emsenn:infomaterial:content> <(ni:\/\/\/sha-256;[A-Za-z0-9_-]{43})> /u;
function rawNi(bytes) { return `ni:///sha-256;${createHash("sha256").update(bytes).digest("base64url")}`; }
function within(root, candidate) { const rel = relative(resolve(root), resolve(candidate)); return rel === "" || (!rel.startsWith("..") && !rel.startsWith("/") && !rel.startsWith("\\")); }
function carrierRole(path) {
  if (path.startsWith("node_modules/") || path.startsWith(".pnpm-store/") || path.includes("/node_modules/")) return "foreign-carrier";
  if (path.includes("/content/assets/legacy/") || path.includes("/content/retired-carriers/")) return "preserved-displaced-material";
  return "operated-candidate";
}
function failures(manifest, account) {
  const claim = manifest?.["x-agentic-metro-enterprise"], result = [];
  if (!claim || typeof claim !== "object") return ["no-sovereign-die-claim"];
  if (typeof claim.actor !== "string" || claim.actor.length === 0) result.push("authority:actor");
  if (!Array.isArray(claim.owners) || claim.owners.length === 0 || claim.owner !== undefined) result.push("authority:owners");
  if (!claim.membrane || typeof claim.membrane !== "object") result.push("custody:membrane");
  if (typeof claim.admission !== "string" || typeof claim.refusal !== "string") result.push("refusal:law");
  const operations = claim["operation-catalog"];
  if (!operations || typeof operations !== "object" || Object.keys(operations).length === 0) result.push("pinout:operations");
  else for (const [name, operation] of Object.entries(operations)) if (!/^ni:\/\/\/sha-256;[A-Za-z0-9_-]{43}$/u.test(operation?.contract ?? "")) result.push(`pinout:${name}:law-identity`);
  if (!account) result.push("authority:smart-account-binding");
  result.push("learning:unmeasured", "value:unmeasured");
  return result;
}

async function contentIdentities(topologyPath, wanted) {
  const found = new Map(), lines = createInterface({ input: createReadStream(topologyPath), crlfDelay: Infinity });
  for await (const line of lines) { if (!line.includes(`<${CONTENT}>`)) continue; const match = line.match(CONTENT_QUAD); if (match && wanted.has(match[1])) found.set(match[1], match[2]); }
  return found;
}

export async function assayClaimedDies({ territoryRoot, topologyPath, topologyIdentity, observationIdentity, materialRoot, entries }) {
  const topology = await verifyMaterialTopology({ path: topologyPath, identity: topologyIdentity, graph: observationIdentity, materialRoot, entries });
  const occurrences = [...topology.packageOccurrences, ...topology.accountOccurrences], wanted = new Set(occurrences.map(({ material }) => material));
  const content = await contentIdentities(topologyPath, wanted), accounts = new Map();
  for (const occurrence of topology.accountOccurrences) {
    const absolute = resolve(territoryRoot, occurrence.path); if (!within(territoryRoot, absolute)) throw new Error("account occurrence escapes territory");
    const bytes = await readFile(absolute), expected = content.get(occurrence.material); if (rawNi(bytes) !== expected) throw new Error(`account bytes drifted since observation: ${occurrence.path}`);
    const value = JSON.parse(bytes); accounts.set(dirname(dirname(dirname(dirname(occurrence.path)))), value);
  }
  const packages = [];
  for (const occurrence of topology.packageOccurrences) {
    const role = carrierRole(occurrence.path); if (role !== "operated-candidate") { packages.push({ path: occurrence.path, role }); continue; }
    const absolute = resolve(territoryRoot, occurrence.path); if (!within(territoryRoot, absolute)) throw new Error("package occurrence escapes territory");
    const bytes = await readFile(absolute), expected = content.get(occurrence.material); if (!expected || rawNi(bytes) !== expected) throw new Error(`package bytes drifted since observation: ${occurrence.path}`);
    const manifest = JSON.parse(bytes), packageRoot = dirname(occurrence.path), account = accounts.get(packageRoot);
    packages.push({ path: occurrence.path, packageRoot, role, name: manifest.name ?? null, nodeId: manifest?.["x-agentic-metro-enterprise"]?.["node-id"] ?? null, binCount: Object.keys(manifest.bin ?? {}).length, operationCount: Object.keys(manifest?.["x-agentic-metro-enterprise"]?.["operation-catalog"] ?? {}).length, account: account?.account?.caip10 ?? null, failures: failures(manifest, account) });
  }
  const operated = packages.filter(({ role }) => role === "operated-candidate"), unresolved = operated.filter(({ failures: value }) => value.length > 0);
  return { profile: "org.emsenn.recursive-fabric.claimed-die-assay.v1", materialRoot, observationIdentity, topologyIdentity, packages: { total: packages.length, operated: operated.length, foreign: packages.filter(({ role }) => role === "foreign-carrier").length, preserved: packages.filter(({ role }) => role === "preserved-displaced-material").length }, claimedDies: operated, unresolvedCuts: unresolved.length };
}
