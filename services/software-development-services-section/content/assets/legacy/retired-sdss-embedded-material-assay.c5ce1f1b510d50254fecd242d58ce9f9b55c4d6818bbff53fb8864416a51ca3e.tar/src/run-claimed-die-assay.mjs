#!/usr/bin/env node
import { assayClaimedDies } from "./claimed-die-assay.mjs";

function option(name) { const index = process.argv.indexOf(name); return index < 0 ? undefined : process.argv[index + 1]; }
const entries = Number(option("--entries"));
const result = await assayClaimedDies({
  territoryRoot: option("--territory"),
  topologyPath: option("--topology"),
  topologyIdentity: option("--topology-identity"),
  observationIdentity: option("--observation-identity"),
  materialRoot: option("--material-root"),
  entries,
});
process.stdout.write(`${JSON.stringify(result)}\n`);
if (process.argv.includes("--enforce") && result.unresolvedCuts > 0) process.exitCode = 1;
