import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { verifyMaterialTopology } from "../src/material-topology-gate.mjs";
import { assayClaimedDies } from "../src/claimed-die-assay.mjs";

const graph = "ni:///sha-256;AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", root = "ni:///sha-256;BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB", occurrence = "ni:///sha-256;CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC";
function identity(source) { return `ni:///sha-256;${createHash("sha256").update(source).digest("base64url")}`; }

test("the material gate verifies the canonical rooted occurrence graph", async () => {
  const directory = await mkdtemp(join(tmpdir(), "material-gate-"));
  const source = [`<${occurrence}> <urn:emsenn:infomaterial:material> <${root}> <${graph}> .`, `<${occurrence}> <urn:emsenn:infomaterial:path> "." <${graph}> .`].sort().join("\n") + "\n";
  const path = join(directory, "topology.nq"); await writeFile(path, source);
  const result = await verifyMaterialTopology({ path, identity: identity(source), graph, materialRoot: root, entries: 1 });
  assert.equal(result.status, "pass"); assert.equal(result.entries, 1);
});

test("the material gate refuses unsorted topology", async () => {
  const directory = await mkdtemp(join(tmpdir(), "material-gate-refusal-"));
  const source = `<${occurrence}> <urn:emsenn:infomaterial:path> "." <${graph}> .\n<${occurrence}> <urn:emsenn:infomaterial:material> <${root}> <${graph}> .\n`;
  const path = join(directory, "topology.nq"); await writeFile(path, source);
  await assert.rejects(verifyMaterialTopology({ path, identity: identity(source), graph, materialRoot: root, entries: 1 }), /not strictly byte-sorted/u);
});

test("the die assay measures current package claims without treating them as earned cuts", async () => {
  const directory = await mkdtemp(join(tmpdir(), "claimed-die-assay-"));
  const manifest = Buffer.from(JSON.stringify({ name: "fixture", "x-agentic-metro-enterprise": { "node-id": "fixture" } }));
  await writeFile(join(directory, "package.json"), manifest);
  const packageMaterial = identity("package-material"), packageOccurrence = identity("package-occurrence"), content = identity(manifest);
  const source = [
    `<${occurrence}> <urn:emsenn:infomaterial:material> <${root}> <${graph}> .`,
    `<${occurrence}> <urn:emsenn:infomaterial:path> "." <${graph}> .`,
    `<${packageMaterial}> <urn:emsenn:infomaterial:content> <${content}> <${graph}> .`,
    `<${packageOccurrence}> <urn:emsenn:infomaterial:material> <${packageMaterial}> <${graph}> .`,
    `<${packageOccurrence}> <urn:emsenn:infomaterial:parent-occurrence> <${occurrence}> <${graph}> .`,
    `<${packageOccurrence}> <urn:emsenn:infomaterial:path> "package.json" <${graph}> .`,
  ].sort().join("\n") + "\n";
  const path = join(directory, "topology.nq"); await writeFile(path, source);
  const result = await assayClaimedDies({ territoryRoot: directory, topologyPath: path, topologyIdentity: identity(source), observationIdentity: graph, materialRoot: root, entries: 2 });
  assert.equal(result.packages.operated, 1); assert.equal(result.unresolvedCuts, 1);
  assert.ok(result.claimedDies[0].failures.includes("authority:smart-account-binding"));
});
